package com.isteve.loginapp.view.activities


import android.content.Intent
import android.os.Bundle
import android.text.TextUtils
import android.widget.Toast
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.isteve.loginapp.R
import com.isteve.loginapp.databinding.ActivityRegisterBinding
import com.isteve.loginapp.view.Firestore.FirestoreClass
import com.isteve.loginapp.view.models.User

class RegisterActivity : BaseActivity() {
    private lateinit var mBinding: ActivityRegisterBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        mBinding = ActivityRegisterBinding.inflate(layoutInflater)
        setContentView(mBinding.root)

        // setUpActionBar()
        // Set a click listener for the toolbar's navigation icon
        mBinding.buttonRegister.setOnClickListener {
            registerUser()
        }
        mBinding.loginHaveAccount.setOnClickListener {
            val intent = Intent(this, LoginActivity::class.java)
            startActivity(intent)
        }
    }
// for navigation backpress

    /**  private fun setUpActionBar() {
    setSupportActionBar(findViewById(R.id.toolbarRegister))
    val actionBar = supportActionBar
    actionBar?.setDisplayHomeAsUpEnabled(true)
    if (actionBar != null) {
    actionBar.setHomeAsUpIndicator(R.drawable.ic_back2)
    actionBar.title = null // Set the title to null
    }
    mBinding.toolbarRegister.setNavigationOnClickListener { onBackPressed() }
    } **/

    private fun validateRegistrationDetails(): Boolean {
        return when {
            TextUtils.isEmpty(mBinding.firstName.text.toString().trim()) -> {
                showErrorBar(resources.getString(R.string.error_msg_firstname), true)
                false
            }

            (TextUtils.isEmpty(mBinding.LastName.text.toString().trim())) -> {
                showErrorBar(resources.getString(R.string.error_msg_lastname), true)
                false
            }

            (TextUtils.isEmpty(mBinding.RegisterEmial.text.toString().trim())) -> {
                showErrorBar(resources.getString(R.string.error_msg_password), true)
                false
            }
            (TextUtils.isEmpty(mBinding.RegisterConfirmEmial.text.toString().trim())) -> {
                showErrorBar(resources.getString(R.string.error_msg_password), true)
                false
            }
            (TextUtils.isEmpty(mBinding.PasswordRegister.text.toString().trim())) -> {
                showErrorBar(resources.getString(R.string.error_msg_password), true)
                false
            }

            else -> {
                true
            }
        }
    }

    private fun registerUser() {
        if (validateRegistrationDetails()) {

            showProgressDialog(resources.getString(R.string.please_wait))

            val email: String = mBinding.RegisterEmial.text.toString().trim()
            val password: String = mBinding.PasswordRegister.text.toString().trim()


            FirebaseAuth.getInstance().createUserWithEmailAndPassword(email, password)
                .addOnCompleteListener { task ->


                    if (task.isSuccessful) {
                        val firebaseUser: FirebaseUser = task.result!!.user!!
                        val user = User(
                            firebaseUser.uid,
                            mBinding.firstName.text.toString().trim(),
                            mBinding.LastName.text.toString().trim(),
                            mBinding.RegisterEmial.text.toString().trim()
                        )

                        FirestoreClass().registerUser(this@RegisterActivity, user)

                        //   FirebaseAuth.getInstance().signOut()
                        // finish()
                    } else {
                        hideProgressDialog()
                        showErrorBar(task.exception!!.message.toString(), true)
                    }
                }
        }
    }

    fun userRegistrationSuccess() {
        hideProgressDialog()
        Toast.makeText(
            this, "Registered Successfully",
            Toast.LENGTH_SHORT
        ).show()
    }
}