package com.isteve.loginapp.view.activities


import android.os.Bundle
import android.view.MenuItem
import android.widget.Toast
import com.google.firebase.auth.FirebaseAuth
import com.isteve.loginapp.R
import com.isteve.loginapp.databinding.ActivityForgotpasswordBinding

class ForgotpasswordActivity : BaseActivity() {

    private lateinit var mBinding: ActivityForgotpasswordBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        mBinding = ActivityForgotpasswordBinding.inflate(layoutInflater)
        setContentView(mBinding.root)

        setUpActionBar()
    }

    private fun setUpActionBar() {
        setSupportActionBar(findViewById(R.id.toolbar))
        val actionBar = supportActionBar
        actionBar?.setDisplayHomeAsUpEnabled(true)
        if (actionBar != null) {
            actionBar.setHomeAsUpIndicator(R.drawable.ic_back2)
            actionBar.title = null // Set the title to null
        }

        mBinding.buttonResetPass.setOnClickListener {
            val email: String = mBinding.edEmailForgotScreen.text.toString().trim()
            if (email.isEmpty()) {
                showErrorBar(resources.getString(R.string.error_msg_password), true)
            } else {
                showProgressDialog(resources.getString(R.string.please_wait))
                FirebaseAuth.getInstance().sendPasswordResetEmail(email)
                    .addOnCompleteListener { task ->
                        hideProgressDialog()
                        if (task.isSuccessful) {
                            Toast.makeText(
                                this,
                                resources.getString(R.string.messge_sent),
                                Toast.LENGTH_LONG
                            ).show()
                            finish()
                        } else {
                            showErrorBar(task.exception!!.message.toString(), true)
                        }

                    }
            }

        }
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        if (item.itemId == android.R.id.home) {
            onBackPressed() // Handle back button click here
            return true
        }
        return super.onOptionsItemSelected(item)
    }
}
