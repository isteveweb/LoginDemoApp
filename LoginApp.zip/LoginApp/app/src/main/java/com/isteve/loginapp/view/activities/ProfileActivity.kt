package com.isteve.loginapp.view.activities

import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.isteve.loginapp.R
import com.isteve.loginapp.databinding.ActivityForgotpasswordBinding
import com.isteve.loginapp.databinding.ActivityProfileBinding
import com.isteve.loginapp.view.Utils.Constants
import com.isteve.loginapp.view.models.User
import java.io.IOException
import java.util.jar.Manifest

class ProfileActivity : BaseActivity() {
    private lateinit var mBinding: ActivityProfileBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        mBinding = ActivityProfileBinding.inflate(layoutInflater)
        setContentView(mBinding.root)

        var userDetails: User = User()
        if (intent.hasExtra(Constants.EXTRA_USER_DETAILS)) {
            userDetails = intent.getParcelableExtra(Constants.EXTRA_USER_DETAILS)!!
        }

        mBinding.firstname.isEnabled = false
        mBinding.firstname.setText(userDetails.firstName)

        mBinding.lastname.isEnabled = false
        mBinding.lastname.setText(userDetails.lastNAme)

        mBinding.emailUp.isEnabled = false
        mBinding.emailUp.setText(userDetails.email)

        mBinding.imageview.setOnClickListener {
            clickImage()
        }
    }

    private fun clickImage() {
        if (ContextCompat.checkSelfPermission(
                this,
                android.Manifest.permission.READ_EXTERNAL_STORAGE
            )
            == PackageManager.PERMISSION_GRANTED
        ) {
            Constants.showImageChoser(this)
        } else {
            ActivityCompat.requestPermissions(
                this, arrayOf(android.Manifest.permission.READ_EXTERNAL_STORAGE),
                Constants.READ_STORAGE_PERMISSION
            )
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            Constants.showImageChoser(this)
        } else {
            Toast.makeText(this, "Permission Denied", Toast.LENGTH_LONG).show()
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == Activity.RESULT_OK) {
            if (requestCode == Constants.PICK_IMAGE) {
                if (data != null) {
                    try {
                        val selectedImageFileUri = data.data!!
                        mBinding.imageview.setImageURI(Uri.parse(selectedImageFileUri.toString()))
                    } catch (e: IOException) {
                        e.printStackTrace()
                        Toast.makeText(
                            this, "Image Selection Failed", Toast.LENGTH_SHORT
                        ).show()
                    }
                }
            }
        } else if ( resultCode == Activity.RESULT_CANCELED)
            Log.e("Request Cancelled", "Image cancelled")
    }
}