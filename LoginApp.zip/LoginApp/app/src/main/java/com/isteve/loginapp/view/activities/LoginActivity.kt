package com.isteve.loginapp.view.activities


import android.content.Intent
import android.os.Bundle
import android.text.TextUtils
import android.util.Log
import com.google.firebase.auth.FirebaseAuth
import com.isteve.loginapp.R
import com.isteve.loginapp.databinding.ActivityLoginBinding
import com.isteve.loginapp.view.Firestore.FirestoreClass
import com.isteve.loginapp.view.Utils.Constants
import com.isteve.loginapp.view.models.User

class LoginActivity : BaseActivity() {

    private lateinit var mBinding: ActivityLoginBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        mBinding = ActivityLoginBinding.inflate(layoutInflater)
        setContentView(mBinding.root)

        mBinding.tvforgotPassword.setOnClickListener {
            val intent = Intent(this, ForgotpasswordActivity::class.java)
            startActivity(intent)
        }

        mBinding.loginHaveAccount.setOnClickListener {
            val intent = Intent(this, RegisterActivity::class.java)
            startActivity(intent)
        }

        mBinding.buttonLogin.setOnClickListener {
            loginRegisteredUser()
        }
    }

    private fun validateLoginDetails(): Boolean {
        return when {
            TextUtils.isEmpty(mBinding.EmailLogin.text.toString().trim()) -> {
                showErrorBar(resources.getString(R.string.error_msg_email), true)
                false
            }
            (TextUtils.isEmpty(mBinding.edPasswordLoginScreen.text.toString().trim())) -> {
                showErrorBar(resources.getString(R.string.error_msg_password), true)
                false
            }
            else -> {
                true
            }
        }
    }

    private fun loginRegisteredUser() {
        if (validateLoginDetails()) {
            showProgressDialog(resources.getString(R.string.please_wait))

            val email: String = mBinding.EmailLogin.text.toString().trim()
            val password: String = mBinding.edPasswordLoginScreen.text.toString().trim()

            FirebaseAuth.getInstance().signInWithEmailAndPassword(email, password)
                .addOnCompleteListener(this) { task ->

                    if (task.isSuccessful) {
                        FirestoreClass().getUserDetails(this)
                    } else {
                        hideProgressDialog()
                        showErrorBar(task.exception?.message.toString(), true)
                    }
                }
        }
    }

    fun userLoggedInSuccess(user: User) {

        hideProgressDialog()
        Log.i("First Name: ", user.firstName)
        Log.i("Last Name: ", user.lastNAme)
        Log.i("Email: ", user.email)

        if (user.profileCompleted == 0) {
            val intent = Intent(this, ProfileActivity::class.java)
            intent.putExtra(Constants.EXTRA_USER_DETAILS, user)
            startActivity(intent)
        } else {
            startActivity(Intent(this, MainActivity::class.java))
        }
        finish()
    }
}