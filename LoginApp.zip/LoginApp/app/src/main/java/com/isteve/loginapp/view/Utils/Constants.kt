package com.isteve.loginapp.view.Utils

import android.app.Activity
import android.content.Intent
import android.provider.MediaStore

object Constants {
    const val READ_STORAGE_PERMISSION = 2
    const val USERS: String = "users"
    const val MY_ZIP_PREFERENCES: String = "ZipPrefs"
    const val LOGGED_IN_USERNAME: String = "logged_in_username"
    const val EXTRA_USER_DETAILS: String = "extra_user_details"
    const val PICK_IMAGE = 1

    fun showImageChoser(activity: Activity) {
        val galleryIntent = Intent(
            Intent.ACTION_PICK,
            MediaStore.Images.Media.EXTERNAL_CONTENT_URI
        )
        activity.startActivityForResult(galleryIntent, PICK_IMAGE)
    }
}