package com.isteve.loginapp.view.activities

import android.app.Dialog
import android.app.ProgressDialog
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Message
import android.widget.TextView
import androidx.core.content.ContextCompat
import com.google.android.material.snackbar.Snackbar
import com.isteve.loginapp.R

open class BaseActivity : AppCompatActivity() {

   private lateinit var mProgressDialog: Dialog

    fun showErrorBar (message: String, errorMessage: Boolean) {
        val snackbar=
            Snackbar.make(findViewById(android.R.id.content), message,Snackbar.LENGTH_LONG)
        val snackBarView = snackbar.view

        if (errorMessage){
            snackBarView.setBackgroundColor(
                ContextCompat.getColor(this,
                R.color.errorColor)
            )
        }
        else{
            snackBarView.setBackgroundColor(
                ContextCompat.getColor( this,
                    R.color.SuccessColor
                )
            )
        }
        snackbar.show()
    }

    fun showProgressDialog(text: String) {
        mProgressDialog = Dialog(this)
        mProgressDialog.setContentView(R.layout.dialog_progress)

        val textViewProgress = mProgressDialog.findViewById<TextView>(R.id.textViewProgress)
        textViewProgress.text = text
        mProgressDialog.setCancelable(false)
        mProgressDialog.setCanceledOnTouchOutside(false)

        mProgressDialog.show()
    }

    fun hideProgressDialog() {
        mProgressDialog.dismiss()
    }
}