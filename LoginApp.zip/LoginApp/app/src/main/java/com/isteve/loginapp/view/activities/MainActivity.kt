package com.isteve.loginapp.view.activities

import android.content.Context
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.isteve.loginapp.R
import com.isteve.loginapp.databinding.ActivityMainBinding
import com.isteve.loginapp.databinding.ActivityRegisterBinding
import com.isteve.loginapp.view.Utils.Constants

class MainActivity : AppCompatActivity() {

    private lateinit var mBinding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        mBinding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(mBinding.root)

        val sharedPreferences = getSharedPreferences(Constants.MY_ZIP_PREFERENCES, Context.MODE_PRIVATE)
        val username = sharedPreferences.getString(Constants.LOGGED_IN_USERNAME, "")!!
        mBinding.tvMain.text = "Welcome to Zip $username"

    }
}